from playsound import playsound

playsound('tm_pkg\\alexander-nakarada-one-bard-band.mp3')